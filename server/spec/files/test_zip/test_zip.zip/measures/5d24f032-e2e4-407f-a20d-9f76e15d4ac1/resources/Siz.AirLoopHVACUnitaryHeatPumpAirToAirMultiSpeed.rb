# *******************************************************************************
# OpenStudio(R), Copyright (c) 2008-2020, Alliance for Sustainable Energy, LLC.
# All rights reserved.
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# (1) Redistributions of source code must retain the above copyright notice,
# this list of conditions and the following disclaimer.
#
# (2) Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.
#
# (3) Neither the name of the copyright holder nor the names of any contributors
# may be used to endorse or promote products derived from this software without
# specific prior written permission from the respective party.
#
# (4) Other than as required in clauses (1) and (2), distributions in any form
# of modifications or other derivative works may not use the "OpenStudio"
# trademark, "OS", "os", or any other confusingly similar designation without
# specific prior written permission from Alliance for Sustainable Energy, LLC.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER(S) AND ANY CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
# THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER(S), ANY CONTRIBUTORS, THE
# UNITED STATES GOVERNMENT, OR THE UNITED STATES DEPARTMENT OF ENERGY, NOR ANY OF
# THEIR EMPLOYEES, BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
# OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
# STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
# OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# *******************************************************************************

class OpenStudio::Model::AirLoopHVACUnitaryHeatPumpAirToAirMultiSpeed
  def maxHeatingCapacity
    heatingCoil.maxHeatingCapacity
  end

  def maxCoolingCapacity
    coolingCoil.maxCoolingCapacity
  end

  def maxAirFlowRate
    vals = []
    if supplyAirFlowRateWhenNoCoolingorHeatingisNeeded.is_initialized
      vals << supplyAirFlowRateWhenNoCoolingorHeatingisNeeded.get
    elsif autosizedSupplyAirFlowRateWhenNoCoolingorHeatingisNeeded.is_initialized
      vals << autosizedSupplyAirFlowRateWhenNoCoolingorHeatingisNeeded.get
    end
    if speed1SupplyAirFlowRateDuringHeatingOperation.is_initialized
      vals << speed1SupplyAirFlowRateDuringHeatingOperation.get
    elsif autosizedSpeed1SupplyAirFlowRateDuringHeatingOperation.is_initialized
      vals << autosizedSpeed1SupplyAirFlowRateDuringHeatingOperation.get
    end
    if speed2SupplyAirFlowRateDuringHeatingOperation.is_initialized
      vals << speed2SupplyAirFlowRateDuringHeatingOperation.get
    elsif autosizedSpeed2SupplyAirFlowRateDuringHeatingOperation.is_initialized
      vals << autosizedSpeed2SupplyAirFlowRateDuringHeatingOperation.get
    end
    if speed3SupplyAirFlowRateDuringHeatingOperation.is_initialized
      vals << speed3SupplyAirFlowRateDuringHeatingOperation.get
    elsif autosizedSpeed3SupplyAirFlowRateDuringHeatingOperation.is_initialized
      vals << autosizedSpeed3SupplyAirFlowRateDuringHeatingOperation.get
    end
    if speed4SupplyAirFlowRateDuringHeatingOperation.is_initialized
      vals << speed4SupplyAirFlowRateDuringHeatingOperation.get
    elsif autosizedSpeed4SupplyAirFlowRateDuringHeatingOperation.is_initialized
      vals << autosizedSpeed4SupplyAirFlowRateDuringHeatingOperation.get
    end
    if speed1SupplyAirFlowRateDuringCoolingOperation.is_initialized
      vals << speed1SupplyAirFlowRateDuringCoolingOperation.get
    elsif autosizedSpeed1SupplyAirFlowRateDuringCoolingOperation.is_initialized
      vals << autosizedSpeed1SupplyAirFlowRateDuringCoolingOperation.get
    end
    if speed2SupplyAirFlowRateDuringCoolingOperation.is_initialized
      vals << speed2SupplyAirFlowRateDuringCoolingOperation.get
    elsif autosizedSpeed2SupplyAirFlowRateDuringCoolingOperation.is_initialized
      vals << autosizedSpeed2SupplyAirFlowRateDuringCoolingOperation.get
    end
    if speed3SupplyAirFlowRateDuringCoolingOperation.is_initialized
      vals << speed3SupplyAirFlowRateDuringCoolingOperation.get
    elsif autosizedSpeed3SupplyAirFlowRateDuringCoolingOperation.is_initialized
      vals << autosizedSpeed3SupplyAirFlowRateDuringCoolingOperation.get
    end
    if speed4SupplyAirFlowRateDuringCoolingOperation.is_initialized
      vals << speed4SupplyAirFlowRateDuringCoolingOperation.get
    elsif autosizedSpeed4SupplyAirFlowRateDuringCoolingOperation.is_initialized
      vals << autosizedSpeed4SupplyAirFlowRateDuringCoolingOperation.get
    end
    if vals.size.zero?
      OpenStudio::OptionalDouble.new
    else
      OpenStudio::OptionalDouble.new(vals.max)
    end
  end

  def maxHeatingCapacityAutosized
    heatingCoil.maxHeatingCapacityAutosized
  end

  def maxCoolingCapacityAutosized
    coolingCoil.maxCoolingCapacityAutosized
  end

  def maxAirFlowRateAutosized
    if supplyAirFlowRateWhenNoCoolingorHeatingisNeeded.is_initialized
      return OpenStudio::OptionalBool.new(false)
    elsif speed1SupplyAirFlowRateDuringHeatingOperation.is_initialized
      return OpenStudio::OptionalBool.new(false)
    elsif speed2SupplyAirFlowRateDuringHeatingOperation.is_initialized
      return OpenStudio::OptionalBool.new(false)
    elsif speed3SupplyAirFlowRateDuringHeatingOperation.is_initialized
      return OpenStudio::OptionalBool.new(false)
    elsif speed4SupplyAirFlowRateDuringHeatingOperation.is_initialized
      return OpenStudio::OptionalBool.new(false)
    elsif speed1SupplyAirFlowRateDuringCoolingOperation.is_initialized
      return OpenStudio::OptionalBool.new(false)
    elsif speed2SupplyAirFlowRateDuringCoolingOperation.is_initialized
      return OpenStudio::OptionalBool.new(false)
    elsif speed3SupplyAirFlowRateDuringCoolingOperation.is_initialized
      return OpenStudio::OptionalBool.new(false)
    elsif speed4SupplyAirFlowRateDuringCoolingOperation.is_initialized
      return OpenStudio::OptionalBool.new(false)
    else
      return OpenStudio::OptionalBool.new(true)
    end
  end

  def performanceCharacteristics
    effs = []
    effs += supplyAirFan.performanceCharacteristics
    effs += heatingCoil.performanceCharacteristics
    effs += coolingCoil.performanceCharacteristics
    return effs
  end
end
